export const categories = [
  {
    id: "cat1",
    name: "Vestidos",
    slug: "vestidos",
    itemCount: 25,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: "cat2",
    name: "Blusas",
    slug: "blusas",
    itemCount: 42,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: "cat3",
    name: "Calças",
    slug: "calcas",
    itemCount: 31,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: "cat4",
    name: "Sapatos",
    slug: "sapatos",
    itemCount: 18,
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: "cat5",
    name: "Acessórios",
    slug: "acessorios",
    itemCount: 50,
    image: "/placeholder.svg?height=400&width=400",
  },
]
